﻿$ErrorActionPreference = 'Stop'
Write-Host 'Exportez votre sauvegarde JSON avant de desinstaller. Fermez CapEmploi 360.'
$answer = Read-Host 'Retirer uniquement les raccourcis et fichiers applicatifs ? (O/N)'
if ($answer -ne 'O' -and $answer -ne 'o') { exit }
$dest = Join-Path $env:LOCALAPPDATA 'CapEmploi360'
$desktop = [Environment]::GetFolderPath('Desktop')
Remove-Item -LiteralPath (Join-Path $desktop 'CapEmploi 360.lnk') -Force -ErrorAction SilentlyContinue
$start = Join-Path ([Environment]::GetFolderPath('Programs')) 'CapEmploi 360'
Remove-Item -LiteralPath (Join-Path $start 'CapEmploi 360.lnk') -Force -ErrorAction SilentlyContinue
if ((Test-Path -LiteralPath $start) -and !(Get-ChildItem -LiteralPath $start)) { Remove-Item -LiteralPath $start }
foreach ($name in @('index.html','LIRE-MOI.txt')) { Remove-Item -LiteralPath (Join-Path $dest $name) -Force -ErrorAction SilentlyContinue }
Write-Host 'Raccourcis et application retires. Le profil navigateur et ses donnees sont conserves.'
Write-Host ('Pour les effacer definitivement apres sauvegarde, supprimez manuellement : ' + $dest)
