# CapEmploi 360 — installation sur téléphone

Cette version est une **PWA indépendante** : elle fonctionne hors connexion après le premier chargement et conserve les données localement sur le téléphone. Elle ne dépend ni de Notion, ni de Gmail, ni d’un moteur IA.

## Avant l’installation

Pour que le navigateur propose l’installation, le dossier doit être publié via une adresse **HTTPS**. L’ouverture directe de `index.html` depuis un gestionnaire de fichiers fonctionne pour consulter l’application, mais ne permet généralement pas l’installation PWA.

## Android

1. Ouvrir l’adresse HTTPS dans Chrome.
2. Appuyer sur **Installer sur ce téléphone** dans l’application, ou ouvrir le menu ⋮ puis **Installer l’application** / **Ajouter à l’écran d’accueil**.
3. Après le premier chargement, l’application peut fonctionner hors connexion.

## iPhone / iPad

1. Ouvrir l’adresse HTTPS dans Safari.
2. Appuyer sur **Partager**.
3. Choisir **Sur l’écran d’accueil**, puis confirmer.

## Données et sauvegardes

Les données restent dans le stockage local du navigateur et ne sont pas synchronisées automatiquement avec Notion. Exporter régulièrement la sauvegarde JSON depuis **Données & Notion**. Une désinstallation ou un effacement des données du navigateur peut supprimer les données locales.

## Limites

Cette version mobile ne réalise aucun envoi Gmail, aucun dépôt sur portail et aucune collecte automatique d’offres. Elle prépare et suit les dossiers ; les envois restent soumis aux vérifications et aux règles de l’agent.
