﻿$ErrorActionPreference = 'Stop'
try {
    $source = Join-Path $PSScriptRoot 'index.html'
    if (!(Test-Path -LiteralPath $source)) { throw 'Extrayez le dossier ZIP complet avant de lancer Installer.cmd.' }
    $dest = Join-Path $env:LOCALAPPDATA 'CapEmploi360'
    $edgeCandidates = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe')
    )
    $edge = $edgeCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (!$edge) { throw 'Microsoft Edge est requis. Vous pouvez aussi ouvrir index.html dans Chrome sans installation.' }
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    foreach ($name in @('index.html','LIRE-MOI.txt','Desinstaller.ps1','Desinstaller.cmd')) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $dest -Force
    }
    $url = ([System.Uri](Join-Path $dest 'index.html')).AbsoluteUri
    $profile = Join-Path $dest 'Navigateur'
    $argsText = '--user-data-dir="' + $profile + '" --app="' + $url + '"'
    $ws = New-Object -ComObject WScript.Shell
    $desktop = [Environment]::GetFolderPath('Desktop')
    $start = Join-Path ([Environment]::GetFolderPath('Programs')) 'CapEmploi 360'
    New-Item -ItemType Directory -Path $start -Force | Out-Null
    foreach ($where in @($desktop,$start)) {
        $shortcut = $ws.CreateShortcut((Join-Path $where 'CapEmploi 360.lnk'))
        $shortcut.TargetPath = $edge
        $shortcut.Arguments = $argsText
        $shortcut.WorkingDirectory = $dest
        $shortcut.Description = 'Suivi local des candidatures - CapEmploi 360'
        $shortcut.Save()
    }
    Write-Host 'Installation terminee. Un raccourci CapEmploi 360 a ete cree sur votre Bureau.'
    Write-Host 'Aucune cle API requise. Aucun envoi automatique active.'
    Start-Process -FilePath $edge -ArgumentList $argsText
} catch {
    Write-Host ('Installation impossible : ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
